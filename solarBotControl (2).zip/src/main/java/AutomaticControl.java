import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AutomaticControl extends JFrame {
    private Main parent;

    public AutomaticControl(Main parent) {
        this.parent = parent;
        setTitle("Automatic Control");
        setSize(400, 300);
        setLayout(new GridLayout(4, 1));

        JButton startButton = new JButton("Start Cleaning");
        startButton.addActionListener(e -> parent.sendCommandToRobot("START_CLEANING"));
        add(startButton);

        JButton stopButton = new JButton("Stop Cleaning");
        stopButton.addActionListener(e -> parent.sendCommandToRobot("STOP_CLEANING"));
        add(stopButton);

        JButton manualButton = new JButton("Manual Control");
        manualButton.addActionListener(e -> parent.openJoystickControl());
        add(manualButton);

        JButton configButton = new JButton("Panel Configuration");
        configButton.addActionListener(e -> parent.openPanelConfig());
        add(configButton);
    }
}
