import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PanelConfiguration extends JFrame {
    private Main parent;
    private JTextField panelLengthField, panelWidthField; // For panel size
    private JTextField[] panelCountFields; // For number of panels per row

    public PanelConfiguration(Main parent) {
        this.parent = parent;
        setTitle("Panel Configuration");
        setSize(400, 300);
        setLayout(new GridLayout(10, 2)); // Allow up to 9 rows

        panelLengthField = new JTextField();
        panelWidthField = new JTextField();
        panelCountFields = new JTextField[9];

        add(new JLabel("Panel Length (mm):"));
        add(panelLengthField);
        add(new JLabel("Panel Width (mm):"));
        add(panelWidthField);

        for (int i = 0; i < 9; i++) {
            add(new JLabel("Row " + (i + 1) + ":"));
            panelCountFields[i] = new JTextField("0");
            add(panelCountFields[i]);
        }

        JButton emergencyStopButton = new JButton("Emergency Stop");
        emergencyStopButton.addActionListener(e -> parent.sendCommandToRobot("EMERGENCY_STOP"));
        add(emergencyStopButton);
    }
}
