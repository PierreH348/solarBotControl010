import javax.swing.*;
import java.awt.*;
import java.io.PrintWriter;
import java.net.Socket;

public class Main extends JFrame {
    private Socket socket;
    private PrintWriter out;
    private boolean connected = false;
    private JTextArea sensorValues; // To display ultrasonic sensor values

    public Main() {
        setTitle("Solar Bot Control");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create main menu buttons with GridLayout
        JPanel menuPanel = new JPanel(new GridLayout(2, 3)); // 2 rows, 3 columns

        JButton autoControlButton = new JButton("Automatic Control");
        autoControlButton.addActionListener(e -> openAutomaticControl());
        menuPanel.add(autoControlButton);

        JButton manualControlButton = new JButton("Manual Control");
        manualControlButton.addActionListener(e -> openJoystickControl());
        menuPanel.add(manualControlButton);

        JButton panelConfigButton = new JButton("Panel Configuration");
        panelConfigButton.addActionListener(e -> openPanelConfig());
        menuPanel.add(panelConfigButton);

        JButton espButton = new JButton("ESP8266 Connection");
        espButton.addActionListener(e -> openESPConnection());
        menuPanel.add(espButton);

        // Add Path Drawing button
        JButton pathDrawingButton = new JButton("Path Drawing");
        pathDrawingButton.addActionListener(e -> openPathDrawing());
        menuPanel.add(pathDrawingButton); // Add button to the menu

        add(menuPanel, BorderLayout.NORTH);

        // Ultrasonic sensor values display
        sensorValues = new JTextArea(5, 20);
        sensorValues.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(sensorValues);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    public void openAutomaticControl() {
        AutomaticControl autoControl = new AutomaticControl(this);
        autoControl.setVisible(true);
    }

    public void openJoystickControl() {
        JoystickControl joystickControl = new JoystickControl(this);
        joystickControl.setVisible(true);
    }

    public void openPanelConfig() {
        PanelConfiguration panelConfig = new PanelConfiguration(this);
        panelConfig.setVisible(true);
    }

    public void openESPConnection() {
        ESP8266Connection espConnection = new ESP8266Connection(this);
        espConnection.setVisible(true);
    }

    // New method to open Path Drawing
    public void openPathDrawing() {
        PathDrawing pathDrawing = new PathDrawing(this);
        pathDrawing.setVisible(true); // Make the PathDrawing window visible
    }

    public void sendCommandToRobot(String command) {
        if (out != null && connected) {
            out.println(command);
            // Removed all JOptionPane notifications for any command
        }
    }

    public void setConnectionStatus(boolean status, PrintWriter writer) {
        connected = status;
        this.out = writer;
    }

    public void displaySensorValues(String values) {
        sensorValues.setText(values); // Update sensor values display
    }

    public static void main(String[] args) {
        new Main();
    }
}
